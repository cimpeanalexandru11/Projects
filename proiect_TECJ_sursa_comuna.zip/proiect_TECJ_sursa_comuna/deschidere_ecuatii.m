function deschidere_ecuatii

open('Ecuatii necesare in elaborarea proiectului.pdf');