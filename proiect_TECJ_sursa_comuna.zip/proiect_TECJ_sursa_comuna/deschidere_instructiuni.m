function deschidere_instructiuni

open('instructiuni_utilizare.txt');