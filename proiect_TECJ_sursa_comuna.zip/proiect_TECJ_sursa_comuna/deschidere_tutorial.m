function deschidere_tutorial

open('Tutorial_program.pdf');