clear all;
close all;

stare_popupmenu=1;
stare_RG=1;
stare_RD=1;
stare_RS=1;
stare_RL=1;
Vgs_psf=0;
f=50;
A=0.2;
phi=0;

interfata(stare_popupmenu,stare_RG,stare_RD,stare_RS,stare_RL,Vgs_psf,f,A,phi);